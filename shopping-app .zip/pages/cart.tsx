import { useCartStore } from "../store/cart";

export default function Cart() {
  const { cart, removeFromCart, updateQuantity } = useCartStore();
  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Shopping Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <div>
          {cart.map((item) => (
            <div key={item.id} className="border p-4 rounded-lg mb-4">
              <img src={item.image} alt={item.title} className="w-20 h-20 object-contain" />
              <h2 className="text-lg font-semibold">{item.title}</h2>
              <p className="text-gray-500">${item.price}</p>
              <div className="flex items-center">
                <button
                  className="bg-red-500 text-white px-2 py-1 rounded"
                  onClick={() => removeFromCart(item.id)}
                >
                  Remove
                </button>
                <input
                  type="number"
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.id, Number(e.target.value))}
                  className="ml-2 border p-1 w-12"
                  min="1"
                />
              </div>
            </div>
          ))}
          <p className="text-xl font-semibold">Total: ${total.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}