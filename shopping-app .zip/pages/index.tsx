import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { useCartStore } from "../store/cart";

export default function Home() {
  const { addToCart } = useCartStore();
  const { data: products, isLoading, error } = useQuery({
    queryKey: ["products"],
    queryFn: async () => (await axios.get("https://fakestoreapi.com/products")).data,
  });

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error loading products</div>;

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Products</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products?.map((product) => (
          <div key={product.id} className="border p-4 rounded-lg">
            <img src={product.image} alt={product.title} className="w-full h-40 object-contain" />
            <h2 className="text-lg font-semibold">{product.title}</h2>
            <p className="text-gray-500">${product.price}</p>
            <button
              className="mt-2 bg-blue-500 text-white px-4 py-2 rounded"
              onClick={() => addToCart(product)}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}